"""Plaza Cerca: aplicación portable. No contiene cuentas ni claves iniciales."""
import hashlib
import hmac
import io
import os
import re
import secrets
import sqlite3
import time
import warnings
from datetime import timedelta
from decimal import Decimal, InvalidOperation
from functools import wraps
from pathlib import Path

import click
from cryptography.fernet import Fernet
from flask import Flask, abort, flash, g, redirect, render_template, request, send_file, session, url_for
from PIL import Image, ImageOps, UnidentifiedImageError
from werkzeug.security import check_password_hash, generate_password_hash

CATEGORIES = ['Hogar', 'Herramientas', 'Tecnología', 'Vehículos', 'Ropa y accesorios', 'Otros']
SCHEMA = '''
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
 password TEXT NOT NULL, admin INTEGER NOT NULL DEFAULT 0,
 verified INTEGER NOT NULL DEFAULT 0, created INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS verifications (
 id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 status TEXT NOT NULL CHECK(status IN ('pending','approved','rejected','expired','cancelled')),
 selfie TEXT, front TEXT, back TEXT, created INTEGER NOT NULL,
 reviewed INTEGER, reviewer INTEGER REFERENCES users(id), reason TEXT NOT NULL DEFAULT '',
 consent_version TEXT NOT NULL DEFAULT '1');
CREATE UNIQUE INDEX IF NOT EXISTS one_pending ON verifications(user_id) WHERE status='pending';
CREATE TABLE IF NOT EXISTS listings (
 id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 title TEXT NOT NULL, description TEXT NOT NULL, price INTEGER NOT NULL,
 category TEXT NOT NULL, location TEXT NOT NULL, phone TEXT NOT NULL,
 state TEXT NOT NULL DEFAULT 'active', created INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS photos (
 id INTEGER PRIMARY KEY, listing_id INTEGER NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
 path TEXT NOT NULL UNIQUE);
CREATE TABLE IF NOT EXISTS rate_limits (
 bucket TEXT PRIMARY KEY, hits INTEGER NOT NULL, expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS audit (
 id INTEGER PRIMARY KEY, actor INTEGER NOT NULL, action TEXT NOT NULL,
 target INTEGER NOT NULL, created INTEGER NOT NULL);
'''

def create_app(test_config=None):
    app = Flask(__name__)
    data = Path(os.environ.get('DATA_DIR', Path(__file__).parent / 'data')).resolve()
    app.config.update(DATA_DIR=data, MAX_CONTENT_LENGTH=26 * 1024 * 1024,
        SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax',
        SESSION_COOKIE_SECURE=os.environ.get('APP_ENV') == 'production',
        PERMANENT_SESSION_LIFETIME=timedelta(hours=8))
    if test_config:
        app.config.update(test_config)
    data = Path(app.config['DATA_DIR'])
    data.mkdir(parents=True, exist_ok=True, mode=0o700)
    for folder in ['public', 'identity']:
        (data / folder).mkdir(exist_ok=True, mode=0o700)

    def local_secret(name, supplied, factory):
        if supplied:
            return supplied
        path = data / name
        try:
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError:
            pass
        else:
            with os.fdopen(fd, 'w') as f:
                f.write(factory())
        return path.read_text().strip()

    if os.environ.get('APP_ENV') == 'production':
        if not os.environ.get('SECRET_KEY') or not os.environ.get('DOCUMENT_KEY'):
            raise RuntimeError('Producción requiere SECRET_KEY y DOCUMENT_KEY.')
        if len(os.environ['SECRET_KEY']) < 32:
            raise RuntimeError('SECRET_KEY debe tener al menos 32 caracteres.')
    app.secret_key = local_secret('session.key', os.environ.get('SECRET_KEY'), lambda: secrets.token_hex(32))
    cipher = Fernet(local_secret('documents.key', os.environ.get('DOCUMENT_KEY'), lambda: Fernet.generate_key().decode()).encode())
    database = data / 'marketplace.sqlite3'
    with sqlite3.connect(database) as connection:
        connection.execute('PRAGMA foreign_keys=ON')
        connection.executescript(SCHEMA)
    os.chmod(database, 0o600)

    def db():
        if 'db' not in g:
            g.db = sqlite3.connect(database, timeout=15)
            g.db.row_factory = sqlite3.Row
            g.db.execute('PRAGMA foreign_keys=ON')
        return g.db

    @app.teardown_appcontext
    def close(_):
        connection = g.pop('db', None)
        if connection is not None:
            connection.close()

    def csrf():
        if 'csrf' not in session:
            session['csrf'] = secrets.token_urlsafe(32)
        return session['csrf']

    def rate_limit(scope, maximum, seconds, subject=None):
        # No se confía en X-Forwarded-For enviado por el cliente.
        subject = subject or request.remote_addr or 'unknown'
        bucket = hmac.new(app.secret_key.encode(), (scope + ':' + subject).encode(), hashlib.sha256).hexdigest()
        now = int(time.time())
        connection = db()
        connection.execute('DELETE FROM rate_limits WHERE expires <= ?', (now,))
        connection.execute('INSERT INTO rate_limits VALUES (?,1,?) ON CONFLICT(bucket) DO UPDATE SET hits=hits+1', (bucket, now + seconds))
        hits = connection.execute('SELECT hits FROM rate_limits WHERE bucket=?', (bucket,)).fetchone()['hits']
        connection.commit()
        if hits > maximum:
            abort(429, 'Demasiados intentos. Esperá unos minutos y volvé a probar.')

    def remove_identity(row):
        for key in ['selfie', 'front', 'back']:
            if row[key]:
                (data / 'identity' / row[key]).unlink(missing_ok=True)

    def purge():
        connection = db()
        connection.execute('BEGIN IMMEDIATE')
        rows = connection.execute('SELECT * FROM verifications WHERE status="pending" AND created < ?', (int(time.time()) - 7 * 86400,)).fetchall()
        for row in rows:
            remove_identity(row)
            connection.execute('UPDATE verifications SET status="expired",selfie=NULL,front=NULL,back=NULL,reason=? WHERE id=?', ('Solicitud vencida después de 7 días. Podés enviarla otra vez.', row['id']))
        connection.commit()
        # Elimina restos de escrituras interrumpidas; jamás expone archivos sin registro.
        known = {r[0] for r in connection.execute('SELECT selfie FROM verifications UNION SELECT front FROM verifications UNION SELECT back FROM verifications') if r[0]}
        for p in (data / 'identity').glob('*.enc'):
            if p.name not in known and p.stat().st_mtime < time.time() - 3600:
                p.unlink(missing_ok=True)
        return len(rows)

    @app.before_request
    def before():
        g.user = db().execute('SELECT * FROM users WHERE id=?', (session.get('uid'),)).fetchone()
        if request.method == 'POST':
            token = request.form.get('csrf', '')
            if not token or not hmac.compare_digest(token, session.get('csrf', '')):
                abort(400, 'La sesión del formulario venció. Recargá la página.')

    @app.after_request
    def headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Referrer-Policy'] = 'same-origin'
        response.headers['Content-Security-Policy'] = "default-src 'self'; img-src 'self'; style-src 'self'; script-src 'none'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'"
        if not request.path.startswith('/static/') and not request.path.startswith('/photo/'):
            response.headers['Cache-Control'] = 'no-store'
        if app.config['SESSION_COOKIE_SECURE']:
            response.headers['Strict-Transport-Security'] = 'max-age=31536000'
        return response

    @app.context_processor
    def context():
        return dict(csrf=csrf, categories=CATEGORIES)

    @app.template_filter('money')
    def money(value):
        return '$ ' + f'{value / 100:,.2f}'.replace(',', 'X').replace('.', ',').replace('X', '.')

    def login_required(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not g.user:
                return redirect(url_for('login'))
            return view(*args, **kwargs)
        return wrapped

    def admin_required(view):
        @wraps(view)
        @login_required
        def wrapped(*args, **kwargs):
            if not g.user['admin']:
                abort(403)
            return view(*args, **kwargs)
        return wrapped

    def field(name, minimum=1, maximum=200):
        value = request.form.get(name, '').strip()
        if not minimum <= len(value) <= maximum:
            raise ValueError(f'Revisá el campo {name}: entre {minimum} y {maximum} caracteres.')
        return value

    def image_bytes(upload):
        if not upload or not upload.filename:
            raise ValueError('Falta una foto. Usá JPG, PNG o WebP.')
        raw = upload.read(6 * 1024 * 1024 + 1)
        if len(raw) > 6 * 1024 * 1024:
            raise ValueError('Cada foto debe pesar como máximo 6 MB.')
        try:
            with warnings.catch_warnings():
                warnings.simplefilter('error', Image.DecompressionBombWarning)
                with Image.open(io.BytesIO(raw)) as im:
                    if im.format not in ['JPEG', 'PNG', 'WEBP'] or im.width * im.height > 24_000_000:
                        raise ValueError('Imagen no admitida; usá JPG, PNG o WebP de hasta 24 megapíxeles.')
                    im.load()
                    im = ImageOps.exif_transpose(im).convert('RGB')
                    im.thumbnail((1800, 1800))
                    output = io.BytesIO()
                    im.save(output, format='JPEG', quality=88)
                    return output.getvalue()
        except (UnidentifiedImageError, OSError, Image.DecompressionBombError, Image.DecompressionBombWarning):
            raise ValueError('No pudimos leer la imagen. Probá con otra foto.')

    @app.get('/')
    def home():
        q = request.args.get('q', '').strip()[:100]
        category = request.args.get('category', '')
        try:
            page = max(1, min(int(request.args.get('page', 1)), 10000))
        except ValueError:
            page = 1
        where = 'l.state="active" AND u.verified=1 AND (l.title LIKE ? OR l.location LIKE ?)'
        params = ['%' + q + '%', '%' + q + '%']
        if category in CATEGORIES:
            where += ' AND l.category=?'
            params.append(category)
        rows = db().execute('SELECT l.*,u.name,(SELECT id FROM photos WHERE listing_id=l.id ORDER BY id LIMIT 1) photo FROM listings l JOIN users u ON u.id=l.user_id WHERE ' + where + ' ORDER BY l.created DESC,l.id DESC LIMIT 13 OFFSET ?', params + [(page - 1) * 12]).fetchall()
        return render_template('home.html', listings=rows[:12], more=len(rows)>12, page=page, q=q, category=category)

    @app.route('/register', methods=['GET', 'POST'])
    def register():
        if request.method == 'POST':
            rate_limit('register', 8, 3600)
            try:
                name = field('nombre', 2, 80)
                email = field('email', 5, 254).lower()
                password = field('clave', 12, 128)
                if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email):
                    raise ValueError('Ingresá un correo válido.')
                if request.form.get('adult') != 'yes':
                    raise ValueError('Esta versión está destinada a mayores de 18 años.')
                cursor = db().execute('INSERT INTO users(name,email,password,created) VALUES (?,?,?,?)', (name, email, generate_password_hash(password), int(time.time())))
                db().commit()
                session.clear()
                session['uid'] = cursor.lastrowid
                session.permanent = True
                return redirect(url_for('account'))
            except (ValueError, sqlite3.IntegrityError) as exc:
                db().rollback()
                flash(str(exc) if isinstance(exc, ValueError) else 'No se pudo crear la cuenta con ese correo. Probá iniciar sesión.', 'error')
        return render_template('auth.html', register=True)

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            rate_limit('login-ip', 30, 900)
            email = request.form.get('email', '').strip().lower()[:254]
            rate_limit('login-email', 10, 900, email)
            user = db().execute('SELECT * FROM users WHERE email=?', (email,)).fetchone()
            password = request.form.get('clave', '')[:129]
            if user and check_password_hash(user['password'], password):
                session.clear()
                session['uid'] = user['id']
                session.permanent = True
                return redirect(url_for('admin' if user['admin'] else 'account'))
            flash('Correo o contraseña incorrectos.', 'error')
        return render_template('auth.html', register=False)

    @app.post('/logout')
    def logout():
        session.clear()
        return redirect(url_for('home'))

    @app.get('/account')
    @login_required
    def account():
        purge()
        verification = db().execute('SELECT * FROM verifications WHERE user_id=? ORDER BY id DESC LIMIT 1', (g.user['id'],)).fetchone()
        listings = db().execute('SELECT * FROM listings WHERE user_id=? ORDER BY id DESC', (g.user['id'],)).fetchall()
        return render_template('account.html', verification=verification, listings=listings)

    @app.post('/verify')
    @login_required
    def verify():
        rate_limit('verify', 5, 3600, str(g.user['id']))
        if g.user['verified']:
            abort(409, 'Tu identidad ya fue revisada.')
        if request.form.get('consent') != 'yes':
            abort(400, 'Necesitamos tu autorización para revisar las imágenes.')
        paths = []
        try:
            payloads = [image_bytes(request.files.get(k)) for k in ['selfie', 'front', 'back']]
            for payload in payloads:
                name = secrets.token_hex(24) + '.enc'
                paths.append(name)
                path = data / 'identity' / name
                with open(path, 'xb') as f:
                    f.write(cipher.encrypt(payload))
                os.chmod(path, 0o600)
            db().execute('INSERT INTO verifications(user_id,status,selfie,front,back,created) VALUES (?,"pending",?,?,?,?)', (g.user['id'], *paths, int(time.time())))
            db().commit()
            flash('Solicitud enviada. El administrador la revisará.', 'success')
        except (ValueError, sqlite3.IntegrityError) as exc:
            db().rollback()
            for name in paths:
                (data / 'identity' / name).unlink(missing_ok=True)
            flash(str(exc) if isinstance(exc, ValueError) else 'Ya tenés una solicitud pendiente.', 'error')
        except Exception:
            db().rollback()
            for name in paths:
                (data / 'identity' / name).unlink(missing_ok=True)
            raise
        return redirect(url_for('account'))

    @app.post('/verify/cancel')
    @login_required
    def cancel_verification():
        connection = db()
        connection.execute('BEGIN IMMEDIATE')
        row = connection.execute('SELECT * FROM verifications WHERE user_id=? AND status="pending"', (g.user['id'],)).fetchone()
        if row:
            remove_identity(row)
            connection.execute('UPDATE verifications SET status="cancelled",selfie=NULL,front=NULL,back=NULL WHERE id=?', (row['id'],))
        connection.commit()
        flash('Solicitud retirada y archivos eliminados.', 'success')
        return redirect(url_for('account'))

    @app.route('/sell', methods=['GET', 'POST'])
    @login_required
    def sell():
        if not g.user['verified']:
            flash('Primero verificá tu identidad para poder publicar.', 'error')
            return redirect(url_for('account'))
        if request.method == 'POST':
            rate_limit('sell', 15, 3600, str(g.user['id']))
            paths = []
            try:
                title = field('titulo', 4, 100)
                description = field('descripcion', 10, 3000)
                category = field('categoria')
                location = field('zona', 2, 80)
                phone = field('whatsapp', 8, 15)
                if category not in CATEGORIES or not re.fullmatch(r'[1-9][0-9]{7,14}', phone):
                    raise ValueError('Elegí una categoría y un WhatsApp internacional, solo números.')
                if request.form.get('public_contact') != 'yes':
                    raise ValueError('Confirmá que querés mostrar tu WhatsApp a los compradores.')
                amount = Decimal(field('precio', 1, 20).replace(',', '.'))
                if not amount.is_finite() or not Decimal('0.01') <= amount <= Decimal('999999999'):
                    raise ValueError('Ingresá un precio válido en pesos.')
                uploads = [u for u in request.files.getlist('fotos') if u.filename]
                if not 1 <= len(uploads) <= 4:
                    raise ValueError('Agregá entre 1 y 4 fotos del producto.')
                payloads = [image_bytes(u) for u in uploads]
                cursor = db().execute('INSERT INTO listings(user_id,title,description,price,category,location,phone,created) VALUES (?,?,?,?,?,?,?,?)', (g.user['id'], title, description, int(amount * 100), category, location, phone, int(time.time())))
                for payload in payloads:
                    name = secrets.token_hex(24) + '.jpg'
                    paths.append(name)
                    (data / 'public' / name).write_bytes(payload)
                    db().execute('INSERT INTO photos(listing_id,path) VALUES (?,?)', (cursor.lastrowid, name))
                db().commit()
                return redirect(url_for('listing', listing_id=cursor.lastrowid))
            except (ValueError, InvalidOperation) as exc:
                db().rollback()
                for name in paths:
                    (data / 'public' / name).unlink(missing_ok=True)
                flash(str(exc) if isinstance(exc, ValueError) else 'Revisá el precio.', 'error')
            except Exception:
                db().rollback()
                for name in paths:
                    (data / 'public' / name).unlink(missing_ok=True)
                raise
        return render_template('sell.html')

    @app.get('/listing/<int:listing_id>')
    def listing(listing_id):
        row = db().execute('SELECT l.*,u.name,u.verified FROM listings l JOIN users u ON l.user_id=u.id WHERE l.id=?', (listing_id,)).fetchone()
        if not row or (row['state'] != 'active' and (not g.user or (g.user['id'] != row['user_id'] and not g.user['admin']))):
            abort(404)
        photos = db().execute('SELECT id FROM photos WHERE listing_id=?', (listing_id,)).fetchall()
        return render_template('listing.html', item=row, photos=photos)

    @app.get('/photo/<int:photo_id>')
    def photo(photo_id):
        row = db().execute('SELECT p.path,l.state,l.user_id FROM photos p JOIN listings l ON p.listing_id=l.id WHERE p.id=?', (photo_id,)).fetchone()
        if not row or (row['state'] != 'active' and (not g.user or (g.user['id'] != row['user_id'] and not g.user['admin']))):
            abort(404)
        return send_file(data / 'public' / row['path'], mimetype='image/jpeg')

    @app.post('/listing/<int:listing_id>/state')
    @login_required
    def listing_state(listing_id):
        row = db().execute('SELECT * FROM listings WHERE id=?', (listing_id,)).fetchone()
        if not row or (row['user_id'] != g.user['id'] and not g.user['admin']):
            abort(403)
        state = request.form.get('state')
        if state not in ['sold', 'removed']:
            abort(400)
        db().execute('UPDATE listings SET state=? WHERE id=?', (state, listing_id))
        db().execute('INSERT INTO audit(actor,action,target,created) VALUES (?,?,?,?)', (g.user['id'], 'listing_' + state, listing_id, int(time.time())))
        db().commit()
        return redirect(url_for('admin' if g.user['admin'] else 'account'))

    @app.get('/admin')
    @admin_required
    def admin():
        purge()
        pending = db().execute('SELECT v.*,u.name,u.email FROM verifications v JOIN users u ON v.user_id=u.id WHERE status="pending" ORDER BY v.id').fetchall()
        recent = db().execute('SELECT v.*,u.name FROM verifications v JOIN users u ON v.user_id=u.id WHERE status!="pending" ORDER BY v.id DESC LIMIT 20').fetchall()
        listings = db().execute('SELECT l.*,u.name FROM listings l JOIN users u ON l.user_id=u.id WHERE state="active" ORDER BY id DESC LIMIT 100').fetchall()
        return render_template('admin.html', pending=pending, recent=recent, listings=listings)

    @app.get('/admin/identity/<int:verification_id>/<kind>')
    @admin_required
    def identity(verification_id, kind):
        if kind not in ['selfie', 'front', 'back']:
            abort(404)
        row = db().execute('SELECT * FROM verifications WHERE id=? AND status="pending" AND created>=?', (verification_id, int(time.time())-7*86400)).fetchone()
        if not row or not row[kind]:
            abort(404)
        payload = cipher.decrypt((data / 'identity' / row[kind]).read_bytes())
        db().execute('INSERT INTO audit(actor,action,target,created) VALUES (?,"view_identity",?,?)', (g.user['id'], verification_id, int(time.time())))
        db().commit()
        return send_file(io.BytesIO(payload), mimetype='image/jpeg', max_age=0)

    @app.post('/admin/review/<int:verification_id>')
    @admin_required
    def review(verification_id):
        decision = request.form.get('decision')
        reason = request.form.get('reason', '').strip()[:500]
        if decision not in ['approved', 'rejected'] or (decision == 'rejected' and not reason):
            abort(400, 'Para rechazar, indicá el motivo.')
        if request.form.get('checked') != 'yes':
            abort(400, 'Confirmá que revisaste las tres imágenes.')
        connection = db()
        connection.execute('BEGIN IMMEDIATE')
        row = connection.execute('SELECT * FROM verifications WHERE id=? AND status="pending" AND created>=?', (verification_id, int(time.time())-7*86400)).fetchone()
        if not row:
            connection.rollback()
            abort(409, 'La solicitud ya fue revisada, retirada o venció.')
        remove_identity(row)
        connection.execute('UPDATE verifications SET status=?,reason=?,reviewed=?,reviewer=?,selfie=NULL,front=NULL,back=NULL WHERE id=?', (decision, reason, int(time.time()), g.user['id'], verification_id))
        connection.execute('UPDATE users SET verified=? WHERE id=?', (int(decision == 'approved'), row['user_id']))
        connection.execute('INSERT INTO audit(actor,action,target,created) VALUES (?,?,?,?)', (g.user['id'], decision, verification_id, int(time.time())))
        connection.commit()
        flash('Revisión guardada. Las imágenes fueron eliminadas.', 'success')
        return redirect(url_for('admin'))

    @app.post('/account/delete')
    @login_required
    def delete_account():
        rate_limit('delete-account', 10, 900, str(g.user['id']))
        if g.user['admin']:
            abort(403, 'La cuenta administradora no se elimina desde este formulario.')
        if not check_password_hash(g.user['password'], request.form.get('clave', '')[:129]):
            abort(400, 'Contraseña incorrecta.')
        connection = db()
        connection.execute('BEGIN IMMEDIATE')
        for row in connection.execute('SELECT * FROM verifications WHERE user_id=?', (g.user['id'],)).fetchall():
            remove_identity(row)
        for row in connection.execute('SELECT p.path FROM photos p JOIN listings l ON p.listing_id=l.id WHERE l.user_id=?', (g.user['id'],)).fetchall():
            (data / 'public' / row['path']).unlink(missing_ok=True)
        connection.execute('DELETE FROM users WHERE id=?', (g.user['id'],))
        connection.commit()
        session.clear()
        flash('Tu cuenta y sus publicaciones se eliminaron.', 'success')
        return redirect(url_for('home'))

    @app.get('/privacy')
    def privacy():
        return render_template('privacy.html')

    for code in [400, 403, 404, 409, 413, 429, 500]:
        def error(exc):
            message = 'No pudimos completar la operación. Volvé a intentarlo.' if exc.code == 500 else {403:'No tenés acceso a esta sección.',404:'No encontramos esta página.',413:'El archivo es demasiado grande. Usá fotos de hasta 6 MB.'}.get(exc.code, exc.description)
            return render_template('error.html', code=exc.code, message=message), exc.code
        app.register_error_handler(code, error)

    @app.cli.command('create-admin')
    @click.option('--email', prompt='Correo administrador')
    @click.option('--name', prompt='Nombre')
    @click.password_option(prompt='Contraseña (mínimo 12 caracteres)')
    def create_admin(email, name, password):
        if len(password) < 12 or len(password) > 128:
            raise click.ClickException('La contraseña debe tener entre 12 y 128 caracteres.')
        if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email):
            raise click.ClickException('Correo inválido.')
        try:
            db().execute('INSERT INTO users(name,email,password,admin,verified,created) VALUES (?,?,?,1,0,?)', (name, email.lower().strip(), generate_password_hash(password), int(time.time())))
            db().commit()
        except sqlite3.IntegrityError:
            raise click.ClickException('Ese correo ya tiene una cuenta. No se modificó su rol.')
        click.echo('Administrador creado. Ingresá en /login.')

    @app.cli.command('purge-documents')
    def purge_command():
        click.echo(f'{purge()} solicitudes vencidas eliminadas.')

    return app
